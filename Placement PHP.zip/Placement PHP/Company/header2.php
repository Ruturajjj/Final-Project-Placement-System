<?php
session_start();
// Redirect if not logged in
if (!isset($_SESSION['company_id'])) {
    header("Location: company_login2.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Placement - Company Portal</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .navbar-brand {
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        .welcome-text {
            color: #0d6efd;
            font-weight: 500;
        }
        .footer {
            background-color: #f8f9fa;
            padding: 20px 0;
            margin-top: auto;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="company_home.php">
            <i class="fas fa-building me-2"></i>Placement Portal
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="company_home.php">
                        <i class="fas fa-home me-1"></i>Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manage_jobs.php">
                        <i class="fas fa-briefcase me-1"></i>Jobs
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="company_profile.php">
                        <i class="fas fa-user-circle me-1"></i>Profile
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt me-1"></i>Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Main Content Container -->
<div class="container flex-grow-1 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="welcome-text mb-0">
            Welcome, <?php echo htmlspecialchars($_SESSION['company_name']); ?>
        </h4>
        <div class="text-muted">
            <i class="fas fa-calendar-alt me-2"></i><?php echo date('F j, Y'); ?>
        </div>
    </div>