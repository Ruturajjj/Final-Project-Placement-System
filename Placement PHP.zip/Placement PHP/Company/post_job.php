<?php
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Job Button</title>
    <link rel="icon" type="image/png" href="../images/college_logo.jpg">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        footer {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: #0066FF;
    color: #fff;
    text-align: center;
    padding: 10px 0;
    z-index: 1000;
}

    </style>
</head>
<body>

<div class="container text-center mt-5">
    <a href="post_job_form.php" class="btn btn-primary btn-lg">Post a Job/Internship</a>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php
include 'footer.php';
?>