
document.querySelector('form').addEventListener('submit', function(e) {
    e.preventDefault();
    clearErrors();
    console.log('Hello')

    // Get form values
    const companyName = document.getElementById('companyName').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const confirmPassword = document.getElementById('confirmPassword').value.trim();

    let isValid = true;

    // Company Name validation
    if (companyName === '') {
        showError('companyName', 'Company name is required');
        isValid = false;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === '') {
        showError('email', 'Email is required');
        isValid = false;
    } else if (!emailRegex.test(email)) {
        showError('email', 'Please enter a valid email address');
        isValid = false;
    }

    // Password validation
    if (password === '') {
        showError('password', 'Password is required');
        isValid = false;
    } else if (password.length < 8) {
        showError('password', 'Password must be at least 8 characters');
        isValid = false;
    }

    // Confirm Password validation
    if (confirmPassword === '') {
        showError('confirmPassword', 'Please confirm your password');
        isValid = false;
    } else if (password !== confirmPassword) {
        showError('confirmPassword', 'Passwords do not match');
        isValid = false;
    }

    // Submit form if all validations pass
    if (isValid) {
        this.submit();
    }
});

function showError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const parent = field.parentElement;
    
    // Add invalid styling
    field.classList.add('is-invalid');
    
    // Create error message element
    const error = document.createElement('div');
    error.className = 'invalid-feedback d-block';
    error.textContent = message;
    
    // Add error message
    parent.appendChild(error);
}

function clearErrors() {
    // Remove all error messages
    document.querySelectorAll('.invalid-feedback').forEach(el => el.remove());
    
    // Remove invalid styling
    document.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
}
