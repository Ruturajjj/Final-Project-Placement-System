<?php
session_start();
include('../config/connect.php');

// Ensure company is logged in
if (!isset($_SESSION['email'])) {
    header("Location: company_login.php");
    exit();
}

// Check if job ID is provided
if (!isset($_GET['id']) && !isset($_POST['job_id'])) {
    echo "Job ID missing!";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process form submission
    $job_id = $_POST['job_id'];
    $job_title = $_POST['job_title'];
    $job_description = $_POST['job_description'];
    $ctc_stipend = $_POST['ctc_stipend'];
    $address = $_POST['address'];
    $type = $_POST['type'];

    // Update query
    $query = "UPDATE job_internship 
              SET job_title = '$job_title', job_description = '$job_description', 
                  ctc_stipend = '$ctc_stipend', address = '$address', type = '$type' 
              WHERE job_internship_id = $job_id";

    if ($conn->query($query)) {
        header("Location: jobs.php");
        exit();
    } else {
        echo "Failed to update job.";
    }
} else {
    // Fetch job details for the edit form
    $job_id = $_GET['id'];
    $query = "SELECT * FROM job_internship WHERE job_internship_id = $job_id";
    $result = $conn->query($query);

    if (!$result || $result->num_rows == 0) {
        echo "Job not found.";
        exit();
    }

    $job = $result->fetch_assoc();
}

include('header.php');
?>

<div class="container mt-4">
    <h2>Edit Job</h2>
    <form action="update_job.php" method="POST">
        <input type="hidden" name="job_id" value="<?php echo $job['job_internship_id']; ?>">

        <div class="mb-3">
            <label class="form-label">Job Title</label>
            <input type="text" name="job_title" class="form-control" value="<?php echo $job['job_title']; ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="job_description" class="form-control" required><?php echo $job['job_description']; ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Salary</label>
            <input type="text" name="ctc_stipend" class="form-control" value="<?php echo $job['ctc_stipend']; ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Location</label>
            <input type="text" name="address" class="form-control" value="<?php echo $job['address']; ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Type</label>
            <select name="type" class="form-control">
                <option value="job" <?php if ($job['type'] == 'job') echo 'selected'; ?>>Job</option>
                <option value="internship" <?php if ($job['type'] == 'internship') echo 'selected'; ?>>Internship</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Update Job</button>
    </form>
</div>

<?php include 'footer.php'; ?>
