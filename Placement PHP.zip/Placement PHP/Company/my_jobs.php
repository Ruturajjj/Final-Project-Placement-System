<?php
session_start();
include('../config/connect.php');

// Ensure company is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['email'];

// Fetch company ID using session email
$companyQuery = "SELECT id FROM company WHERE email = '$email'";
$companyResult = $conn->query($companyQuery);

if (!$companyResult || $companyResult->num_rows == 0) {
    echo "Company not found.";
    exit();
}

$company = $companyResult->fetch_assoc();
$company_id = $company['id'];

// Fetch jobs posted by this company
$query = "SELECT j.job_internship_id, j.job_title, j.job_description, j.ctc_stipend, j.address, j.type
          FROM job_internship j
          JOIN offers o ON j.job_internship_id = o.job_internship_id
          WHERE o.company_id = $company_id";

$result = $conn->query($query);

include('header.php');
?>

<div class="container mt-4">
    <h2 class="mb-4">Your Posted Jobs</h2>

    <?php while ($row = $result->fetch_assoc()) { ?>
        <div class="card mb-3 shadow">
            <div class="card-body">
                <h5 class="card-title"><?php echo $row['job_title']; ?></h5>
                <p class="card-text"><strong>Salary:</strong> <?php echo $row['ctc_stipend']; ?></p>
                <p class="card-text"><strong>Location:</strong> <?php echo $row['address']; ?></p>
                <p class="card-text"><strong>Type:</strong> <?php echo ucfirst($row['type']); ?></p>
                <a href="update_job.php?id=<?php echo $row['job_internship_id']; ?>" class="btn btn-warning">Update</a>
                <a href="delete_job.php?id=<?php echo $row['job_internship_id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this job?');">Delete</a>
            </div>
        </div>
    <?php } ?>
</div>

<?php include 'footer.php'; ?>
