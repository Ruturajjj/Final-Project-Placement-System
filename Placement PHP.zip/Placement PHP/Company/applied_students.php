<?php
include '../config/connect.php';
include 'header.php';

if (isset($_GET['job_id'])) {
    $job_id = $_GET['job_id'];
    $query_students = "SELECT s.full_name, s.email, d.dept_name, s.cgpa, s.no_atkt, a.status
                       FROM apply a
                       JOIN students s ON a.control_id = s.control_id
                       JOIN department d ON s.dept_id = d.dept_id
                       WHERE a.job_internship_id = '$job_id'";
    $result_students = mysqli_query($conn, $query_students);
}
?>

<div class="container mt-4">
    <h2>Applied Students</h2>
    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Department</th>
                <th>CGPA</th>
                <th>KT's</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($student = mysqli_fetch_assoc($result_students)): ?>
                <tr>
                    <td><?= htmlspecialchars($student['full_name']) ?></td>
                    <td><?= htmlspecialchars($student['email']) ?></td>
                    <td><?= htmlspecialchars($student['dept_name']) ?></td>
                    <td><?= htmlspecialchars($student['cgpa']) ?></td>
                    <td><?= htmlspecialchars($student['no_atkt']) ?></td>
                    <td>
                        <span class="badge bg-<?= $student['status'] === 'Selected' ? 'success' : ($student['status'] === 'Rejected' ? 'danger' : 'warning') ?>">
                            <?= htmlspecialchars($student['status']) ?>
                        </span>
                    </td>
                    <td>
                        <form method="post" action="update_status.php" class="d-flex">
                            <input type="hidden" name="job_id" value="<?= $job_id ?>">
                            <input type="hidden" name="email" value="<?= $student['email'] ?>">
                            <select name="status" class="form-select me-2">
                                <option value="Pending" <?= $student['status'] === 'Pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="Selected" <?= $student['status'] === 'Selected' ? 'selected' : '' ?>>Selected</option>
                                <option value="Rejected" <?= $student['status'] === 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                            </select>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>
