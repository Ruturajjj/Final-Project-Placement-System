<?php
include '../config/connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $job_id = $_POST['job_id'];
    $email = $_POST['email'];
    $status = $_POST['status'];

    $update_query = "UPDATE apply 
                     SET status = '$status' 
                     WHERE job_internship_id = '$job_id' 
                     AND control_id = (SELECT control_id FROM students WHERE email = '$email')";

    if (mysqli_query($conn, $update_query)) {
        header("Location: applied_students.php?job_id=$job_id&status_updated=1");
    } else {
        echo "Error updating status.";
    }
}
?>
