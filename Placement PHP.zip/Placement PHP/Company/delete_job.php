<?php
session_start();
include('../config/connect.php');

if (!isset($_SESSION['email']) || !isset($_GET['id'])) {
    header("Location: login.php");
    exit();
}

$job_id = $_GET['id'];

// Delete job from job_internship and offers table
$query = "DELETE FROM job_internship WHERE job_internship_id = $job_id";

if ($conn->query($query)) {
    header("Location: jobs.php");
} else {
    echo "Failed to delete job.";
}
?>
