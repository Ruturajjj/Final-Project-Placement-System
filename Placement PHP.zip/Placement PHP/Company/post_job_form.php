<?php
session_start();

// Check if the company is logged in using email session
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Include database connection
include('../config/connect.php');

// Fetch all departments for checkboxes
$departments = [];
$deptQuery = "SELECT * FROM department";
$deptResult = mysqli_query($conn, $deptQuery);
while ($row = mysqli_fetch_assoc($deptResult)) {
    $departments[] = $row;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $job_title = $_POST['job_title'];
    $job_description = $_POST['job_description'];
    $address = $_POST['address'];
    $type = $_POST['type'];
    $ctc_stipend = $_POST['ctc_stipend'];
    $no_kt_allowed = $_POST['no_kt_allowed'];
    $vacancies = $_POST['vacancies'];
    $duration = ($type == 'job') ? NULL : $_POST['duration'];
    $req_cgpa = $_POST['req_cgpa'];
    $selected_departments = $_POST['departments'] ?? [];

    // Insert into job_internship table
    $query = "INSERT INTO job_internship (job_title, job_description, address, type, ctc_stipend, no_kt_allowed, vacancies, duration, req_cgpa) 
              VALUES ('$job_title', '$job_description', '$address', '$type', '$ctc_stipend', '$no_kt_allowed', '$vacancies', '$duration', '$req_cgpa')";
    
    if (mysqli_query($conn, $query)) {
        $job_internship_id = mysqli_insert_id($conn);

        // Insert into offers table (Get company_id using email)
        $company_email = $_SESSION['email'];
        $companyQuery = "SELECT id FROM company WHERE email = '$company_email'";
        $companyResult = mysqli_query($conn, $companyQuery);
        if ($companyRow = mysqli_fetch_assoc($companyResult)) {
            $company_id = $companyRow['id'];
            mysqli_query($conn, "INSERT INTO offers (company_id, job_internship_id) VALUES ('$company_id', '$job_internship_id')");
        }

        // Insert departments into job_for table
        if (in_array("all", $selected_departments)) {
            foreach ($departments as $dept) {
                mysqli_query($conn, "INSERT INTO job_for (job_internship_id, dept_id) VALUES ('$job_internship_id', '{$dept['dept_id']}')");
            }
        } else {
            foreach ($selected_departments as $dept_id) {
                mysqli_query($conn, "INSERT INTO job_for (job_internship_id, dept_id) VALUES ('$job_internship_id', '$dept_id')");
            }
        }

        echo "<script>alert('Job posted successfully!'); window.location.href = 'company_home.php';</script>";
    } else {
        echo "<script>alert('Error posting job. Please try again.'); window.history.back();</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Job/Internship</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .form-label {
            font-weight: 600;
        }
    </style>
    <script>
        function toggleDurationField() {
            var jobType = document.getElementById("type").value;
            var durationField = document.getElementById("duration-field");
            if (jobType === "job") {
                durationField.style.display = "none";
                document.getElementById("duration").value = "";
            } else {
                durationField.style.display = "block";
            }
        }

        function toggleAllDepartments(checkbox) {
            let deptCheckboxes = document.querySelectorAll(".dept-checkbox");
            deptCheckboxes.forEach(cb => cb.checked = checkbox.checked);
        }
    </script>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Post Job/Internship</h2>
        <div class="card p-4">
            <form action="" method="POST">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="job_title" class="form-label">Job Title</label>
                            <input type="text" class="form-control" id="job_title" name="job_title" placeholder="Job Title" required>
                        </div>
                        <div class="mb-3">
                            <label for="job_description" class="form-label">Job Description</label>
                            <textarea class="form-control" id="job_description" name="job_description" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="address" class="form-label">Location</label>
                            <textarea class="form-control" id="address" name="address" rows="2" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="type" class="form-label">Type</label>
                            <select class="form-select" id="type" name="type" required onchange="toggleDurationField()">
                                <option value="job">Job</option>
                                <option value="internship">Internship</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="ctc_stipend" class="form-label">CTC/Stipend</label>
                            <input type="text" class="form-control" id="ctc_stipend" name="ctc_stipend" placeholder="E.g. 5 LPA or ₹20,000/month" required>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="no_kt_allowed" class="form-label">Allowed KTs</label>
                            <input type="number" class="form-control" id="no_kt_allowed" name="no_kt_allowed" min="0" required>
                        </div>
                        <div class="mb-3">
                            <label for="vacancies" class="form-label">Vacancies</label>
                            <input type="number" class="form-control" id="vacancies" name="vacancies" min="1" required>
                        </div>
                        <div class="mb-3" id="duration-field">
                            <label for="duration" class="form-label">Internship Duration</label>
                            <input type="text" class="form-control" id="duration" name="duration" placeholder="E.g. 6 months">
                        </div>
                        <div class="mb-3">
                            <label for="req_cgpa" class="form-label">Minimum CGPA</label>
                            <input type="number" step="0.01" class="form-control" id="req_cgpa" name="req_cgpa" min="0" max="10" required>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Select Departments:</label><br>
                    <input type="checkbox" id="all_departments" name="departments[]" value="all" onclick="toggleAllDepartments(this)">
                    <label for="all_departments" class="fw-bold">All Departments</label><br>

                    <?php foreach ($departments as $dept) { ?>
                        <input type="checkbox" name="departments[]" value="<?= $dept['dept_id']; ?>" class="dept-checkbox">
                        <label><?= $dept['dept_name']; ?></label><br>
                    <?php } ?>
                </div>

                <button type="submit" class="btn btn-primary w-100 mt-3">Post Job</button>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <script>window.onload = toggleDurationField;</script>
</body>
</html>
