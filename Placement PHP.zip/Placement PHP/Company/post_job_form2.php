<?php
session_start();

// Check if the company is logged in using email session
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Include database connection
include('../config/connect.php');

// Fetch all departments for the checkbox list
$departments = [];
$deptQuery = "SELECT * FROM department";
$deptResult = mysqli_query($conn, $deptQuery);
while ($row = mysqli_fetch_assoc($deptResult)) {
    $departments[] = $row;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $job_description = $_POST['job_description'];
    $address = $_POST['address'] ?? NULL;
    $ctc_stipend = $_POST['ctc_stipend'];
    $type = $_POST['type'];
    $no_kt_allowed = $_POST['no_kt_allowed'];
    $vacancies = $_POST['vacancies'];
    $duration = ($type == 'job') ? NULL : $_POST['duration'];
    $req_cgpa = $_POST['req_cgpa'];
    $selected_departments = $_POST['departments'] ?? [];

    // Insert job/internship into job_internship table
    $query = "INSERT INTO job_internship (job_description, address, ctc_stipend, type, no_kt_allowed, vacancies, duration, req_cgpa) 
              VALUES ('$job_description', '$address', '$ctc_stipend', '$type', '$no_kt_allowed', '$vacancies', '$duration', '$req_cgpa')";
    
    if (mysqli_query($conn, $query)) {
        $job_internship_id = mysqli_insert_id($conn); // Get the inserted job ID

        // Insert into offers table (Assuming company table has company_id)
        $company_email = $_SESSION['email'];
        $companyQuery = "SELECT company_id FROM company WHERE email = '$company_email'";
        $companyResult = mysqli_query($conn, $companyQuery);
        if ($companyRow = mysqli_fetch_assoc($companyResult)) {
            $company_id = $companyRow['company_id'];
            mysqli_query($conn, "INSERT INTO offers (company_id, job_internship_id) VALUES ('$company_id', '$job_internship_id')");
        }

        // If "All Departments" is selected, insert for all departments
        if (in_array("all", $selected_departments)) {
            foreach ($departments as $dept) {
                $dept_id = $dept['dept_id'];
                mysqli_query($conn, "INSERT INTO job_for (job_internship_id, dept_id) VALUES ('$job_internship_id', '$dept_id')");
            }
        } else {
            // Insert selected departments into job_for table
            foreach ($selected_departments as $dept_id) {
                mysqli_query($conn, "INSERT INTO job_for (job_internship_id, dept_id) VALUES ('$job_internship_id', '$dept_id')");
            }
        }

        echo "<script>alert('Job posted successfully!'); window.location.href = 'company_home.php';</script>";
    } else {
        echo "<script>alert('Error posting job. Please try again.'); window.history.back();</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Job</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function toggleDuration() {
            let jobType = document.getElementById("type").value;
            let durationField = document.getElementById("duration_field");
            if (jobType === "job") {
                durationField.style.display = "none";
                document.getElementById("duration").value = "";
            } else {
                durationField.style.display = "block";
            }
        }

        function toggleAllDepartments(checkbox) {
            let deptCheckboxes = document.querySelectorAll(".dept-checkbox");
            deptCheckboxes.forEach(cb => cb.checked = checkbox.checked);
        }
    </script>
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center mb-4">Post a Job or Internship</h2>
    <form action="" method="POST" class="shadow p-4 rounded bg-light">
        
        <div class="mb-3">
            <label for="job_description" class="form-label">Job Description:</label>
            <textarea name="job_description" class="form-control" required></textarea>
        </div>

        <div class="mb-3">
            <label for="address" class="form-label">Address:</label>
            <input type="text" name="address" class="form-control">
        </div>

        <div class="mb-3">
            <label for="ctc_stipend" class="form-label">CTC/Stipend:</label>
            <input type="text" name="ctc_stipend" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="type" class="form-label">Type:</label>
            <select name="type" id="type" class="form-select" required onchange="toggleDuration()">
                <option value="job">Job</option>
                <option value="internship">Internship</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="no_kt_allowed" class="form-label">Number of KTs Allowed:</label>
            <input type="number" name="no_kt_allowed" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="vacancies" class="form-label">Vacancies:</label>
            <input type="number" name="vacancies" class="form-control" required>
        </div>

        <div class="mb-3" id="duration_field" style="display: none;">
            <label for="duration" class="form-label">Duration:</label>
            <input type="text" name="duration" id="duration" class="form-control">
        </div>

        <div class="mb-3">
            <label for="req_cgpa" class="form-label">Required CGPA:</label>
            <input type="number" step="0.01" name="req_cgpa" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Select Departments:</label><br>
            <input type="checkbox" id="all_departments" name="departments[]" value="all" onclick="toggleAllDepartments(this)">
            <label for="all_departments" class="fw-bold">All Departments</label><br>

            <?php foreach ($departments as $dept) { ?>
                <input type="checkbox" name="departments[]" value="<?= $dept['dept_id']; ?>" class="dept-checkbox">
                <label><?= $dept['dept_name']; ?></label><br>
            <?php } ?>
        </div>

        <div class="text-center">
            <button type="submit" class="btn btn-primary w-100">Post Job</button>
        </div>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
