<?php
// Include the database connection
include('../config/connect.php'); 

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $companyName = $_POST['companyName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['cpassword'];

    // Validate that passwords match
    if ($password !== $confirmPassword) {
        echo "<script>alert('Passwords do not match. Please try again.'); window.history.back();</script>";
        exit;
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Check if email already exists
    $query = "SELECT * FROM company WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        echo "<script>alert('Email already exists. Please use a different email.'); window.history.back();</script>";
    } else {
        // Insert company data into the database
        $insertQuery = "INSERT INTO company (company_name, email, password) VALUES ('$companyName', '$email', '$hashedPassword')";
        if (mysqli_query($conn, $insertQuery)) {
            echo "<script>alert('Registration successful!'); window.location.href = 'company_login.php';</script>";
        } else {
            echo "<script>alert('Error during registration. Please try again later.'); window.history.back();</script>";
        }
    }
}
?>
