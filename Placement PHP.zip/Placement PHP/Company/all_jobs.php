<?php
session_start();
include '../config/connect.php';
include 'header.php';

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$company_email = $_SESSION['email'];

// Fetch company ID
$query_company = "SELECT id FROM company WHERE email = '$company_email'";
$result_company = mysqli_query($conn, $query_company);
$company = mysqli_fetch_assoc($result_company);
$company_id = $company['id'];
?>

<div class="container mt-4">
    <h2 class="mb-3">Your Posted Jobs & Internships</h2>
    <table class="table table-striped table-bordered">
        <thead class="table-primary">
            <tr>
                <th>Job/Internship Title</th>
                <th>Type</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query_jobs = "SELECT j.job_internship_id, j.job_title, j.type 
                           FROM job_internship j
                           JOIN offers o ON j.job_internship_id = o.job_internship_id
                           WHERE o.company_id = '$company_id'";
            $result_jobs = mysqli_query($conn, $query_jobs);

            while ($job = mysqli_fetch_assoc($result_jobs)): ?>
                <tr>
                    <td><?= htmlspecialchars($job['job_title']) ?></td>
                    <td>
                        <span class="badge bg-<?= $job['type'] === 'job' ? 'success' : 'info' ?>">
                            <?= ucfirst($job['type']) ?>
                        </span>
                    </td>
                    <td>
                        <a href="applied_students.php?job_id=<?= $job['job_internship_id'] ?>" class="btn btn-primary btn-sm">
                            View Applied Students
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>
