<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Login</title>
    <link rel="icon" type="image/png" href="../images/college_logo.jpg">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        // JavaScript function to validate email format
        function validateEmail() {
            const emailInput = document.getElementById("email");
            const emailValue = emailInput.value;
            const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

            if (!emailPattern.test(emailValue)) {
                alert("Please enter a valid email address.");
                emailInput.focus();
                return false;
            }
            return true;
        }
    </script>
</head>

<body>
    <div class="container-fluid vh-100">
        <div class="row h-100">
            <!-- Image Section -->
            <div class="col-lg-6 col-md-6 col-sm-12 d-none d-md-block bg-light text-center">
                <img src="../images/Company.jpg" class="img-fluid h-80 w-80" alt="Login Image" style="object-fit: cover;">
            </div>

            <!-- Login Form Section -->
            <div class="col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-center bg-white">
                <div class="w-75">
                    <h2 class="text-center mb-4">Company Login</h2>
                    <form action="" method="POST" onsubmit="return validateEmail();">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Enter your company email" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-100">Login</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php
session_start();
// Include the database connection
include('../config/connect.php'); 


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Query to check if the email exists
    $query = "SELECT * FROM company WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    // Validate email and password
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        // Verify password
        if (password_verify($password, $row['password'])) {
           
            $_SESSION['email'] = $email;
            echo "<script>alert('Login successful!'); window.location.href = 'company_home.php';</script>";
            exit;
        }
    }

    // Generic error message for invalid credentials
    echo "<script>alert('Invalid email or password. Please try again.'); window.history.back();</script>";
}
?>
