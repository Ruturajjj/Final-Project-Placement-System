<?php
// Start session and include necessary files
session_start();
include '../config/connect.php';
include 'header.php';

// Check if the company is logged in
if (!isset($_SESSION['email'])) {
    header("Location: company_login.php");
    exit();
}

$email = $_SESSION['email'];

// Fetch company details
$sql = "SELECT company_name, email FROM company WHERE email = '$email'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) === 0) {
    echo "Company not found!";
    exit();
}

$company = mysqli_fetch_assoc($result);

// Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $new_company_name = mysqli_real_escape_string($conn, $_POST['company_name']);
    $new_email = mysqli_real_escape_string($conn, $_POST['email']);

    if ($new_email !== $email) {
        // Check if the new email already exists
        $check_email_sql = "SELECT id FROM company WHERE email = '$new_email'";
        $check_result = mysqli_query($conn, $check_email_sql);

        if (mysqli_num_rows($check_result) > 0) {
            $error_message = "Email already in use. Please choose another email.";
        } else {
            // Update name and email
            $update_sql = "UPDATE company SET company_name = '$new_company_name', email = '$new_email' WHERE email = '$email'";

            if (mysqli_query($conn, $update_sql)) {
                $_SESSION['email'] = $new_email;
                $success_message = "Profile updated successfully!";
                $email = $new_email;
                $company['company_name'] = $new_company_name;
                $company['email'] = $new_email;
            } else {
                $error_message = "Failed to update profile: " . mysqli_error($conn);
            }
        }
    } else {
        // Update only the name if email is unchanged
        $update_sql = "UPDATE company SET company_name = '$new_company_name' WHERE email = '$email'";

        if (mysqli_query($conn, $update_sql)) {
            $success_message = "Profile updated successfully!";
            $company['company_name'] = $new_company_name;
        } else {
            $error_message = "Failed to update profile: " . mysqli_error($conn);
        }
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: company_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Profile</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h1 class="text-center mb-4">Company Profile</h1>

    <!-- Success/Error Messages -->
    <?php if (isset($success_message)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success_message; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error_message; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Profile Card -->
    <div class="card">
        <div class="card-body">
            <h3 class="card-title">Company Details</h3>
            <p><strong>Company Name:</strong> <?php echo htmlspecialchars($company['company_name']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($company['email']); ?></p>

            <!-- Update & Logout Buttons -->
            <button class="btn btn-primary" data-toggle="modal" data-target="#updateProfileModal">Update Profile</button>
            <a href="?logout=true" class="btn btn-danger ml-3">Logout</a>
        </div>
    </div>
</div>

<!-- Update Profile Modal -->
<div class="modal fade" id="updateProfileModal" tabindex="-1" role="dialog" aria-labelledby="updateProfileModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updateProfileModalLabel">Update Profile</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="company_name">Company Name</label>
                        <input type="text" class="form-control" id="company_name" name="company_name" value="<?php echo htmlspecialchars($company['company_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Company Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($company['email']); ?>" required>
                    </div>
                    <button type="submit" name="update_profile" class="btn btn-success">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

