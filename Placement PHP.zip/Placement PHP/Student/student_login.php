<?php
session_start();
// Include the database connection
include('../config/connect.php');

$error = ""; // Variable to store error messages

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Query to verify the user
    $query = "SELECT * FROM students WHERE email = '$email'";
    $result = $conn->query($query);

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        // Verify password
        if (password_verify($password, $user['password'])) {
            $_SESSION['email'] = $email;
            header("Location: student_home.php"); // Redirect to home page on success
            exit;
        } else {
            $error = "Invalid credentials.";
        }
    } else {
        $error = "Email not registered.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login Page</title>
    <link rel="stylesheet" href="style.css">
    <script>
        // JavaScript for form validation
        function validateForm() {
            const emailField = document.getElementById('email');
            const emailValue = emailField.value.trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!emailRegex.test(emailValue)) {
                alert('Please enter a valid email address.');
                emailField.focus();
                return false; // Prevent form submission
            }
            return true; // Allow form submission
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="image-section">
            <img src="../images/logo2.png" alt="login Image">
        </div>
        <div class="form-section">
            <h2>Student Login</h2>
            <!-- Display error message if any -->
            <?php if (!empty($error)): ?>
                <div style="color: red;"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="POST" action="" onsubmit="return validateForm()">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>

                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>

                <button type="submit" name="login">Login</button>
            </form>
            <p class="login-link">Don't have an account? <a href="student_register.php">Register here</a></p>
        </div>
    </div>
</body>
</html>
