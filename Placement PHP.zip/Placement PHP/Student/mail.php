<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer library files
require '../vendor/autoload.php'; // Adjust path based on your setup

$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'placeme1@placement.whf.bz';
    $mail->Password = 'UiMa#L3$PMeK';//'usapazscazjbcbjv'; // Use the app password
    $mail->SMTPSecure = 'tls';
    $mail->SMTPOptions = [
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
        ],
    ];
    
    $mail->Port = 465;

    // Recipients
    $mail->setFrom('placeme1@placement.whf.bz', 'Placement System');
    $mail->addAddress('rutu9179@gmail.com'); // Recipient's email address

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Test Email from placement.whf.bz';
    $mail->Body    = '<p>Hello! Ruturaj.</p>';

    $mail->send();
    echo 'Email sent successfully!';
} catch (Exception $e) {
    echo "Failed to send email. Error: {$mail->ErrorInfo}";
}
?>
