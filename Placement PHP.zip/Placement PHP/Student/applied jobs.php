<?php
include 'header.php';
// Start the session to get the logged-in student's email
session_start();

// Include your database connection
include '../config/connect.php';

// Check if the student is logged in
if (!isset($_SESSION['email'])) {
    echo "Please log in to view your applied jobs.";
    exit();
}

$email = $_SESSION['email'];

// Get the control_id from the email
$sql = "SELECT control_id FROM students WHERE email = '$email'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) === 0) {
    echo "Student not found!";
    exit();
}

$row = mysqli_fetch_assoc($result);
$control_id = $row['control_id'];

// Fetch applied jobs with company name and status
$sql = "SELECT ji.job_title, ji.ctc_stipend, ji.type, c.company_name, a.status, a.application_date 
        FROM apply a
        INNER JOIN job_internship ji ON a.job_internship_id = ji.job_internship_id
        INNER JOIN offers o ON ji.job_internship_id = o.job_internship_id
        INNER JOIN company c ON o.company_id = c.id
        WHERE a.control_id = '$control_id'
        ORDER BY a.application_date DESC";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Applied Jobs</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h1 class="text-center mb-4">My Applied Jobs</h1>

    <?php if (mysqli_num_rows($result) > 0): ?>
        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Job Title</th>
                    <th>Company Name</th>
                    <th>CTC/Stipend</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Applied On</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['job_title']); ?></td>
                        <td><?php echo htmlspecialchars($row['company_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['ctc_stipend']); ?></td>
                        <td><?php echo ucfirst($row['type']); ?></td>
                        <td>
                            <span class="badge 
                                <?php echo ($row['status'] === 'Selected') ? 'badge-success' : 
                                            (($row['status'] === 'Rejected') ? 'badge-danger' : 'badge-warning'); ?>">
                                <?php echo $row['status']; ?>
                            </span>
                        </td>
                        <td><?php echo date('d M Y, h:i A', strtotime($row['application_date'])); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="alert alert-info" role="alert">
            You haven't applied for any jobs yet.
        </div>
    <?php endif; ?>

    <?php
    // Close the database connection
    mysqli_close($conn);
    ?>
</div>

<!-- Bootstrap JS (optional) -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
