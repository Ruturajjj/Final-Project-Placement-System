<?php
// Start the session
session_start();

// Include the database connection
include '../config/connect.php'; // Ensure this file contains the connection in a variable like $conn

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = mysqli_real_escape_string($conn, $_POST['fullName']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirmPassword = mysqli_real_escape_string($conn, $_POST['cpassword']);

    // Validate passwords
    if ($password !== $confirmPassword) {
        echo "<script>alert('Passwords do not match.'); window.history.back();</script>";
        exit;
    }

    // Check if the email already exists
    $query = "SELECT email FROM students WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        echo "<script>alert('Email already exists. Please use a different email.'); window.history.back();</script>";
    } else {
        // Store information in session
        $_SESSION['fullName'] = $fullName;
        $_SESSION['email'] = $email;
        $_SESSION['password'] = password_hash($password, PASSWORD_BCRYPT); // Secure password hashing

        // Redirect to the next form
        header("Location: student_details_2.php");
        exit;
    }
}

// No need to close the connection here; it can stay active for other operations
?>
