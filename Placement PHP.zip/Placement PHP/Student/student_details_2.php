<?php
session_start();
include '../config/connect.php'; // Include database connection file
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Details</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid vh-100">
        <div class="row h-100">
            <!-- Image Section -->
            <div class="col-lg-6 col-md-6 col-sm-12 d-none d-md-block bg-light text-center">
                <img src="../images/register.jpg" class="img-fluid h-100 w-100" alt="Student Details Image" style="object-fit: cover;">
            </div>

            <!-- Student Details Form Section -->
            <div class="col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-center bg-white">
                <div class="w-75">
                    <h2 class="text-center mb-4">Student Details</h2>
                    <form action="submit_student_details.php" method="POST">
                        <div class="mb-3">
                            <label for="control_id" class="form-label">Control Id</label>
                            <input type="text" class="form-control" id="control_id" name="control_id" placeholder="Enter your Control Id" required>
                        </div>
                        <div class="mb-3">
                            <label for="department" class="form-label">Department</label>
                            <select class="form-select" id="department" name="dept_id" required>
                                <option value="" disabled selected>Select your department</option>
                                <?php
                                // Fetch departments from the database
                                $sql = "SELECT dept_id, dept_name FROM department";
                                $result = mysqli_query($conn, $sql);

                                if ($result) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<option value='" . $row['dept_id'] . "'>" . $row['dept_name'] . "</option>";
                                    }
                                } else {
                                    echo "<option value='' disabled>Error loading departments</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="year" class="form-label">Year</label>
                            <select class="form-select" id="year" name="year" required>
                                <option value="" disabled selected>Select your year</option>
                                <option value="1">1st Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="cgpa" class="form-label">CGPA</label>
                            <input type="number" step="0.01" class="form-control" id="cgpa" name="cgpa" placeholder="Enter your CGPA" required>
                        </div>
                        <div class="mb-3">
                            <label for="noOfAtkt" class="form-label">Number of ATKTs</label>
                            <input type="number" class="form-control" id="noOfAtkt" name="noOfAtkt" placeholder="Enter number of ATKTs" required>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-100">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

