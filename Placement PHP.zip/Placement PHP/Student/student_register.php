<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../images/college_logo.jpg">
    <title>Registration Page</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid vh-100">
        <div class="row h-100">
            <!-- Image Section -->
            <div class="col-lg-6 col-md-6 col-sm-12 d-none d-md-block bg-light text-center">
                <img src="../images/register.jpg" class="img-fluid h-80 w-80" alt="Registration Image" style="object-fit: cover;">
            </div>

            <!-- Registration Form Section -->
            <div class="col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-center bg-white">
                <div class="w-75">
                    <h2 class="text-center mb-4">Student Registration</h2>
                    <form action="register.php" method="POST">
                        <div class="mb-3">
                            <label for="fullName" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="fullName" name="fullName" placeholder="Enter your full name" maxlength="75" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password"  placeholder="Enter your password" minlength="5" maxlength="20" required>
                        </div>
                        <div class="mb-3">
                            <label for="confirmPassword" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="confirmPassword" name="cpassword" placeholder="Confirm your password" minlength="5" maxlength="20" required>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-100">Continue</button>
                        </div>
                        <p class="login-link">Alredy registered? <a href="student_login.php">Login here</a></p>
                </div>
        
                         </div>
                    </form>
                    
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
