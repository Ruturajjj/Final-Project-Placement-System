<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <style>
        .error-message {
            color: #dc3545;
            font-size: 0.875em;
            margin-top: 0.25rem;
        }
    </style>
</head>

<body>
    <div class="container-fluid vh-100">
        <div class="row h-100">
            <!-- Image Section -->
            <div class="col-lg-6 col-md-6 col-sm-12 d-none d-md-block bg-light text-center p-0">
                <img src="../images/register.jpg" class="img-fluid h-100 w-100" 
                     alt="Registration Image" 
                     style="object-fit: cover;">
            </div>

            <!-- Registration Form Section -->
            <div class="col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-center bg-white">
                <div class="w-75">
                    <h2 class="text-center mb-4">Student Registration</h2>
                    <form action="register.php" method="POST" id="registrationForm">
                        <!-- Full Name Field -->
                        <div class="mb-3">
                            <label for="fullName" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="fullName" name="fullName" 
                                   placeholder="Enter your full name" maxlength="75" required>
                        </div>

                        <!-- Email Field with Validation -->
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   placeholder="Enter your email" required>
                            <div class="error-message" id="emailError"></div>
                        </div>

                        <!-- Password Field with Validation -->
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password"  
                                   placeholder="Enter your password (min 8 characters)" minlength="8" required>
                            <div class="error-message" id="passwordError"></div>
                        </div>

                        <!-- Confirm Password Field -->
                        <div class="mb-3">
                            <label for="confirmPassword" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="confirmPassword" name="cpassword" 
                                   placeholder="Confirm your password" required>
                        </div>

                        <div class="text-center mb-3">
                            <button type="submit" class="btn btn-primary w-100">Continue</button>
                        </div>
                        <p class="text-center">Already registered? <a href="student_login.php">Login here</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery Validation Script -->
    <script>
        $(document).ready(function() {
            // Email validation pattern
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            // Real-time email validation
            $('#email').on('input', function() {
                const email = $(this).val();
                if (!emailRegex.test(email)) {
                    $('#emailError').text('Please enter a valid email address');
                } else {
                    $('#emailError').text('');
                }
            });

            // Real-time password validation
            $('#password').on('input', function() {
                const password = $(this).val();
                if (password.length < 8) {
                    $('#passwordError').text('Password must be at least 8 characters');
                } else {
                    $('#passwordError').text('');
                }
            });

            // Form submission handler
            $('#registrationForm').submit(function(e) {
                let isValid = true;

                // Validate email
                const email = $('#email').val();
                if (!emailRegex.test(email)) {
                    $('#emailError').text('Please enter a valid email address');
                    isValid = false;
                }

                // Validate password length
                const password = $('#password').val();
                if (password.length < 8) {
                    $('#passwordError').text('Password must be at least 8 characters');
                    isValid = false;
                }

                if (!isValid) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>

</html>