<?php
session_start();
include('../config/connect.php');

if (!isset($_SESSION['email'])) {
    header("Location: student_login.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("Job ID not provided.");
}

$job_id = intval($_GET['id']);
$email = $_SESSION['email'];

// Fetch student details
$student_query = "SELECT control_id, dept_id, cgpa, no_atkt FROM students WHERE email = '$email'";
$student_result = $conn->query($student_query);
$student = $student_result->fetch_assoc();

if (!$student) {
    die("Student record not found.");
}

$control_id = $student['control_id'];
$student_cgpa = $student['cgpa'];
$student_no_atkt = $student['no_atkt'];

// Fetch job details with company info
$query = "SELECT j.*, c.company_name 
          FROM job_internship j
          JOIN offers o ON j.job_internship_id = o.job_internship_id
          JOIN company c ON o.company_id = c.id
          WHERE j.job_internship_id = $job_id";
$result = $conn->query($query);

if ($result->num_rows == 0) {
    die("Job not found.");
}

$job = $result->fetch_assoc();
$required_cgpa = $job['req_cgpa'];
$max_no_atkt = $job['no_kt_allowed'];

// Check if student has already applied
$apply_check_query = "SELECT * FROM apply WHERE job_internship_id = '$job_id' AND control_id = '$control_id'";
$apply_check_result = $conn->query($apply_check_query);
$already_applied = $apply_check_result->num_rows > 0;

// Check eligibility
$eligible = ($student_cgpa >= $required_cgpa && $student_no_atkt <= $max_no_atkt);

// Handle application
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['apply'])) {
    if ($already_applied) {
        echo "<script>alert('You have already applied for this job.'); window.location.href='job_details.php?id=$job_id';</script>";
    } elseif (!$eligible) {
        echo "<script>alert('You are not eligible for this job.'); window.location.href='job_details.php?id=$job_id';</script>";
    } else {
        $apply_query = "INSERT INTO apply (job_internship_id, control_id, application_date, status) VALUES ('$job_id', '$control_id', NOW(), 'Pending')";
        if ($conn->query($apply_query) === TRUE) {
            echo "<script>alert('Applied successfully!'); window.location.href='job_details.php?id=$job_id';</script>";
        } else {
            echo "<script>alert('Application failed. Try again.'); window.location.href='job_details.php?id=$job_id';</script>";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelkar Placement</title>
    <link rel="icon" type="image/png" href="../images/college_logo.jpg">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-4"><?php echo htmlspecialchars($job['company_name']); ?></h2>

    <div class="card shadow">
        <div class="card-body">
            <p><strong>Company:</strong> <?php echo htmlspecialchars($job['company_name']); ?></p>
            <p><strong>Job Title:</strong> <?php echo htmlspecialchars($job['job_title']); ?></p>
            <p><strong>Salary:</strong> <?php echo htmlspecialchars($job['ctc_stipend']); ?></p>
            <p><strong>Location:</strong> <?php echo htmlspecialchars($job['address']); ?></p>
            <p><strong>Type:</strong> <?php echo ucfirst(htmlspecialchars($job['type'])); ?></p>
            <p><strong>Duration:</strong> <?php echo $job['duration'] ? htmlspecialchars($job['duration']) : 'N/A'; ?></p>
            <p><strong>Required CGPA:</strong> <?php echo htmlspecialchars($required_cgpa); ?></p>
            <p><strong>Max ATKTs Allowed:</strong> <?php echo htmlspecialchars($max_no_atkt); ?></p>
            <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($job['job_description'])); ?></p>

            <?php if ($already_applied): ?>
                <button class="btn btn-secondary" disabled>Already Applied</button>
            <?php elseif (!$eligible): ?>
                <button class="btn btn-danger" disabled>Not Eligible</button>
            <?php else: ?>
                <form method="POST" action="">
                    <button type="submit" name="apply" class="btn btn-success">Apply Now</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
