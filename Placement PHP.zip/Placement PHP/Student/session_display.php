<?php
session_start();

echo $_SESSION["name"];// provide Id in square brackeyt

?>