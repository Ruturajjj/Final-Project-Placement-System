<?php
session_start();
include 'mail-setup.php'; // Includes the PHPMailer setup function

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Function to generate and send OTP
function sendOTP($email) {
    echo "Configuring email for $email<br>";
    $otp = rand(100000, 999999); // Generate a 6-digit OTP or 4-digit decide later
    $_SESSION['otp'] = $otp; // Store OTP in session

    $mail = setupMailer(); // Get the configured PHPMailer instance or object

    try {
        $mail->addAddress($email); // Use email from session (User's email)
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Verification Code';
        $mail->Body = "<p>Your OTP is <strong>$otp</strong>.</p><p>Please use this code to verify your email.</p>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        die("Error sending email: {$mail->ErrorInfo}");
    }
}



 //Send OTP using email stored in session
 if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
    if (sendOTP($email)) {
        header('Location: otp-verification2.php'); // Redirect to OTP verification page
         exit;
     }
 } else {
     die("No email found in session. Please restart the process.");
 }
?>
