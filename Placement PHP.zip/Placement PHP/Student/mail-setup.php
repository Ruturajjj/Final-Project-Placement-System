<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php'; // Composer's autoload

function setupMailer() {
    $mail = new PHPMailer(true);

    try {
        // SMTP configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; 
        $mail->SMTPAuth = true;
        $mail->Username = 'placementsystem94@gmail.com'; // placement email
        $mail->Password = 'usapazscazjbcbjv'; // Your password
        $mail->SMTPSecure = 'tls';
        $mail->SMTPOptions = [
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
        ],
    ];
        $mail->Port = 587;

        $mail->setFrom('placementsystem94@gmail.com', 'Placement System'); // Sender info

        return $mail;
    } catch (Exception $e) {
        die("Mailer Error: {$mail->ErrorInfo}");
    }
}
?>
