
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Details</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid vh-100">
        <div class="row h-100">
            <!-- Image Section -->
            <div class="col-lg-6 col-md-6 col-sm-12 d-none d-md-block bg-light text-center">
                <img src="https://via.placeholder.com/500x500" class="img-fluid h-100 w-100" alt="Student Details Image" style="object-fit: cover;">
            </div>

            <!-- Student Details Form Section -->
            <div class="col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-center bg-white">
                <div class="w-75">
                    <h2 class="text-center mb-4">Student Details</h2>
                    <form action="/submit-details" method="POST">
                        <div class="mb-3">
                            <div class="mb-3">
                                <label for="control_id" class="form-label">Control Id</label>
                                <input type="text"  class="form-control" id="control_id" name="control_id" placeholder="Enter your Control Id" required>
                            </div>
                            <label for="department" class="form-label">Department</label>
                            <select class="form-select" id="department" name="department" required>
                                <option value="" disabled selected>Select your department</option>
                                <option value="CSE">Computer Science Engineering</option>
                                <option value="IT">Information Technology</option>
                                <option value="ECE">Electronics and Communication Engineering</option>
                                <option value="ME">Mechanical Engineering</option>
                                <option value="EE">Electrical Engineering</option>
                                <option value="CE">Civil Engineering</option>
                                <option value="BT">Biotechnology</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="cgpa" class="form-label">CGPA</label>
                            <input type="number" step="0.01" class="form-control" id="cgpa" name="cgpa" placeholder="Enter your CGPA" required>
                        </div>
                        <div class="mb-3">
                            <label for="noOfAtkt" class="form-label">Number of ATKTs</label>
                            <input type="number" class="form-control" id="noOfAtkt" name="noOfAtkt" placeholder="Enter number of ATKTs" required>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-100">Submit</button>
                        </div>
                        <?php
                        session_start();
echo  $_SESSION['fullName'];
echo  $_SESSION['email'];
echo  $_SESSION['password'];
?>

                        
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
