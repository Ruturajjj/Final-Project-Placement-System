<?php
session_start();
include('../config/connect.php');

// Ensure the student is logged in
if (!isset($_SESSION['email'])) {
    header("Location: student_login.php");
    exit();
}

$email = $_SESSION['email'];

// Fetch student department
$studentQuery = "SELECT dept_id FROM students WHERE email = '$email'";
$studentResult = $conn->query($studentQuery);

if (!$studentResult || $studentResult->num_rows == 0) {
    echo "Student data not found.";
    exit();
}

$student = $studentResult->fetch_assoc();
$dept_id = $student['dept_id'];

// Fetch jobs relevant to the student’s department
$query = "SELECT j.job_internship_id, j.job_title, j.job_description, j.ctc_stipend, j.address, j.type, c.company_name 
          FROM job_internship j
          JOIN job_for jf ON j.job_internship_id = jf.job_internship_id
          JOIN offers o ON j.job_internship_id = o.job_internship_id
          JOIN company c ON o.company_id = c.id
          WHERE jf.dept_id = $dept_id";

$result = $conn->query($query);

include('header.php');
?>

<!-- Navbar with Search -->
<!-- Navbar with Centered Search -->
<nav class="navbar navbar-light bg-light">
    <div class="container d-flex justify-content-center">
        <form class="d-flex">
            <input class="form-control me-2" type="search" id="searchInput" placeholder="Search jobs..." onkeyup="filterJobs()" style="width: 400px;">
            <button class="btn btn-primary" type="button" onclick="filterJobs()">Search</button>
        </form>
    </div>
</nav>


<div class="container mt-4">
    <h2 class="mb-4">Available Jobs</h2>

    <div id="jobList">
        <?php while ($row = $result->fetch_assoc()) { ?>
            <div class="card mb-3 shadow job-card">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title job-company"><?php echo $row['company_name']; ?></h5>
                        <p class="card-text"><strong>Job Title:</strong> <span class="job-title"><?php echo $row['job_title']; ?></span></p>
                        <p class="card-text"><strong>Salary:</strong> <?php echo $row['ctc_stipend']; ?></p>
                        <p class="card-text"><strong>Location:</strong> <?php echo $row['address']; ?></p>
                    </div>
                    <a href="job_details.php?id=<?php echo $row['job_internship_id']; ?>" class="btn btn-primary">View More</a>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<script>
    function filterJobs() {
        let input = document.getElementById("searchInput").value.toLowerCase();
        let jobCards = document.querySelectorAll(".job-card");

        jobCards.forEach(function(card) {
            let title = card.querySelector(".job-title").innerText.toLowerCase();
            let company = card.querySelector(".job-company").innerText.toLowerCase();

            if (title.includes(input) || company.includes(input)) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }
        });
    }
</script>

<?php include 'footer.php'; ?>
