<?php
session_start();
include '../config/connect.php'; // Including  database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $otp_parts = $_POST['otp'];
    $enteredOtp = implode('', $otp_parts);
    // $enteredOtp = $_POST['otp'];

    // Check if the entered OTP matches the one stored in session
    if ($enteredOtp == $_SESSION['otp']) {
        // OTP is verified
        $_SESSION['otp_verified'] = true;

        // Insert data into the database
        $control_id = $_SESSION['control_id'];
        $dept_id = $_SESSION['dept_id'];
        $cgpa = $_SESSION['cgpa'];
        $no_atkt = $_SESSION['noOfAtkt'];
        $email = $_SESSION['email'];
        $password = $_SESSION['password'];
        $fullName = $_SESSION['fullName'];
        $year = $_SESSION['year'];

        // Insert query
        $sql = "INSERT INTO students (control_id, full_name, email, password, no_atkt, cgpa, year, dept_id)
                VALUES ('$control_id', '$fullName', '$email', '$password', '$no_atkt', '$cgpa', '$year', '$dept_id')";

        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Registration successful!'); window.location.href = 'success.html';</script>";
            session_destroy(); // Clear session after successful insertion
            header("Location: student_login.php");
            exit;
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        $error = "Invalid OTP. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid vh-100">
        <div class="row h-100">
            <!-- Image Section -->
            <div class="col-lg-6 col-md-6 d-none d-md-block bg-light">
                <img src="../images/register.jpg" class="img-fluid h-100 w-100" alt="OTP Verification Image" style="object-fit: cover;">
            </div>
            <!-- OTP Verification Form Section -->
            <div class="col-lg-6 col-md-6 d-flex align-items-center justify-content-center bg-white">
                <div class="w-75">
                    <h2 class="text-center mb-4">OTP Verification</h2>
                    <!-- Error Message -->
                    <?php if (isset($error)) { echo "<p class='text-danger text-center'>" . htmlspecialchars($error) . "</p>"; } ?>

                    <!-- OTP Input Form -->
                    <form method="POST" action="">
                        <div class="d-flex justify-content-center mb-4">
                            <!-- Six textboxes for OTP -->
                            <input type="text" class="form-control text-center mx-1" style="width: 50px;" maxlength="1" name="otp[]" id="otp1" oninput="moveToNext(this, 'otp2')" required>
                            <input type="text" class="form-control text-center mx-1" style="width: 50px;" maxlength="1" name="otp[]" id="otp2" oninput="moveToNext(this, 'otp3')" required>
                            <input type="text" class="form-control text-center mx-1" style="width: 50px;" maxlength="1" name="otp[]" id="otp3" oninput="moveToNext(this, 'otp4')" required>
                            <input type="text" class="form-control text-center mx-1" style="width: 50px;" maxlength="1" name="otp[]" id="otp4" oninput="moveToNext(this, 'otp5')" required>
                            <input type="text" class="form-control text-center mx-1" style="width: 50px;" maxlength="1" name="otp[]" id="otp5" oninput="moveToNext(this, 'otp6')" required>
                            <input type="text" class="form-control text-center mx-1" style="width: 50px;" maxlength="1" name="otp[]" id="otp6" oninput="moveToNext(this, '')" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Verify OTP</button>
                    </form>
                    <!-- Send Again Link -->
                    <div class="text-center mt-3">
                        <a href="send-otp.php" class="text-decoration-none">Send Again</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Automatically move to the next input box
        function moveToNext(current, nextFieldID) {
            if (current.value.length === 1 && nextFieldID) {
                document.getElementById(nextFieldID).focus();
            }
        }
    </script>
</body>
</html>
