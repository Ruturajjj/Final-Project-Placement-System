<?php 
// Include database connection and header
include('../config/connect.php');
include 'header.php'; 
session_start();

// Check if the user is logged in
if (!isset($_SESSION["email"])) {
    header("Location: login.php");
    exit();
}

// Fetch user data
$email = $_SESSION["email"];
$query = "SELECT * FROM Students WHERE email = '$email'";
$result = mysqli_query($conn, $query);

$user = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = mysqli_real_escape_string($conn, trim($_POST["full_name"]));
    $control_id = mysqli_real_escape_string($conn, trim($_POST["control_id"]));

    // Validate input
    if (empty($full_name) || empty($control_id)) {
        $error = "All fields are required.";
    } else {
        // Update the user data in the database
        $update_query = "UPDATE Students SET full_name = '$full_name', control_id = '$control_id' WHERE email = '$email'";
        if (mysqli_query($conn, $update_query)) {
            $success = "Profile updated successfully!";
            // Refresh user data
            $result = mysqli_query($conn, $query);
            $user = mysqli_fetch_assoc($result);
        } else {
            $error = "Failed to update profile. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
</head>
<body>
    <div class="container mt-5">
        <h2>Update Profile</h2>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <!-- Update Profile Form -->
        <form method="POST" action="">
            <div class="mb-3">
                <label for="full_name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="full_name" name="full_name" 
                       value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="control_id" class="form-label">Control ID</label>
                <input type="text" class="form-control" id="control_id" name="control_id" 
                       value="<?php echo htmlspecialchars($user['control_id']); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Update Profile</button>
        </form>
    </div>
</body>
</html>
<?php 
// Include footer
include 'footer.php'; 
?>
