<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php'; // Composer's autoload

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Function to generate and send OTP
function sendOTP($email) {
    $otp = rand(100000, 999999); // Generate a 6-digit OTP
    $_SESSION['otp'] = $otp; // Store OTP in session

    $mail = new PHPMailer(true); // Create a new PHPMailer instance

    try {
        // SMTP configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'placementsystem94@gmail.com'; // Your email
        $mail->Password = 'usapazscazjbcbjv'; // Your app password
        $mail->SMTPSecure = 'tls';
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true,
            ],
        ];
        $mail->Port = 587;

        $mail->setFrom('placementsystem94@gmail.com', 'Placement System'); // Sender info
        $mail->addAddress($email); // Recipient email
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Verification Code';
        $mail->Body = "<p>Your OTP is <strong>$otp</strong>.</p><p>Please use this code to verify your email.</p>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        die("Error sending email: {$mail->ErrorInfo}");
    }
}

// Send OTP using email stored in session
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
    if (sendOTP($email)) {
        header('Location: otp-verification2.php'); // Redirect to OTP verification page
        exit;
    }
} else {
    die("No email found in session. Please restart the process.");
}
?>
