<?php
include('../config/connect.php'); // Include the database connection

// Check if all form fields are set
if (isset($_POST['fullname'], $_POST['control-id'], $_POST['email'], $_POST['department'], $_POST['cgpa'], $_POST['no-atkt'], $_POST['year'], $_POST['password'], $_POST['confirm-password'])) {
    
    // Sanitize input data
    $full_name = mysqli_real_escape_string($conn, $_POST['fullname']);
    $control_id = mysqli_real_escape_string($conn, $_POST['control-id']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);
    $cgpa = mysqli_real_escape_string($conn, $_POST['cgpa']);
    $no_atkt = mysqli_real_escape_string($conn, $_POST['no-atkt']);
    $year = mysqli_real_escape_string($conn, $_POST['year']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm-password']);

    // Check if passwords match
    if ($password !== $confirm_password) {
        echo "Passwords do not match!";
    } else {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert the data into the database
        $sql = "INSERT INTO students (control_id, full_name, email, department, cgpa, no_atkt, year, password) 
                VALUES ('$control_id', '$full_name', '$email', '$department', '$cgpa', '$no_atkt', '$year', '$hashed_password')";

        if ($conn->query($sql) === TRUE) {
            echo "success"; // Output success message
        } else {
            echo "Error: " . $conn->error; // Handle error if query fails
        }
    }
} else {
    echo "Form data is missing!"; // Handle missing form data
}

$conn->close(); // Close the database connection
?>
