<?php
include('header.php');
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: student_login.php");
    exit;
}

include('../config/connect.php');

$email = $_SESSION['email'];

// Fetch student details
$query = "SELECT s.control_id, s.full_name, s.email, s.no_atkt, s.cgpa, s.year, d.dept_name, s.dept_id 
          FROM students s 
          JOIN department d ON s.dept_id = d.dept_id 
          WHERE s.email = '$email'";

$result = $conn->query($query);

if ($result->num_rows !== 1) {
    echo "Error: User not found.";
    exit;
}

$student = $result->fetch_assoc();

// Fetch department list for dropdown
$departments = $conn->query("SELECT dept_id, dept_name FROM department");

// Handle AJAX Profile Update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $control_id = $_POST['control_id'];
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $cgpa = $_POST['cgpa'];
    $no_atkt = $_POST['no_atkt'];
    $year = $_POST['year'];
    $dept_id = $_POST['dept_id'];

    $update_query = "UPDATE students SET 
                     full_name = '$full_name', 
                     email = '$email', 
                     cgpa = '$cgpa', 
                     no_atkt = '$no_atkt', 
                     year = '$year', 
                     dept_id = '$dept_id' 
                     WHERE control_id = '$control_id'";

    if ($conn->query($update_query) === TRUE) {
        echo json_encode(["success" => true, "message" => "Profile updated successfully."]);
    } else {
        echo json_encode(["success" => false, "message" => "Error updating profile: " . $conn->error]);
    }
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-header text-center">
                    <h2>Student Profile</h2>
                </div>
                <div class="card-body">
                    
                    <!-- Success/Error Messages -->
                    <div id="message" class="alert d-none"></div>

                    <!-- Profile Details -->
                    <table class="table table-bordered">
                        <tr><th>Control ID</th><td><?= htmlspecialchars($student['control_id']); ?></td></tr>
                        <tr><th>Full Name</th><td id="display_full_name"><?= htmlspecialchars($student['full_name']); ?></td></tr>
                        <tr><th>Email</th><td id="display_email"><?= htmlspecialchars($student['email']); ?></td></tr>
                        <tr><th>CGPA</th><td id="display_cgpa"><?= htmlspecialchars($student['cgpa']); ?></td></tr>
                        <tr><th>Number of ATKTs</th><td id="display_no_atkt"><?= htmlspecialchars($student['no_atkt']); ?></td></tr>
                        <tr><th>Year</th><td id="display_year"><?= htmlspecialchars($student['year']); ?></td></tr>
                        <tr><th>Department</th><td id="display_department"><?= htmlspecialchars($student['dept_name']); ?></td></tr>
                    </table>

                    <!-- Update Profile & Logout Buttons -->
                    <div class="d-flex justify-content-center gap-3">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#updateModal">
                            Update Profile
                        </button>
                        <a href="logout.php" class="btn btn-danger">
                            Logout
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Update Profile Modal -->
<div class="modal fade" id="updateModal" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updateModalLabel">Update Profile</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="updateForm">
                    <input type="hidden" id="control_id" value="<?= htmlspecialchars($student['control_id']); ?>">
                    
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Full Name</label>
                        <input type="text" id="full_name" class="form-control" value="<?= htmlspecialchars($student['full_name']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" id="email" class="form-control" value="<?= htmlspecialchars($student['email']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="cgpa" class="form-label">CGPA</label>
                        <input type="number" step="0.01" min="0" max="10" id="cgpa" class="form-control" value="<?= htmlspecialchars($student['cgpa']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="no_atkt" class="form-label">Number of ATKTs</label>
                        <input type="number" min="0" id="no_atkt" class="form-control" value="<?= htmlspecialchars($student['no_atkt']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="year" class="form-label">Year</label>
                        <input type="number" min="1" max="5" id="year" class="form-control" value="<?= htmlspecialchars($student['year']); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="dept_id" class="form-label">Department</label>
                        <select id="dept_id" class="form-control">
                            <?php while ($dept = $departments->fetch_assoc()): ?>
                                <option value="<?= $dept['dept_id']; ?>" <?= ($dept['dept_id'] == $student['dept_id']) ? 'selected' : ''; ?>>
                                    <?= htmlspecialchars($dept['dept_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-success w-100">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function () {
    $("#updateForm").submit(function (event) {
        event.preventDefault();

        var formData = $(this).serialize();

        $.ajax({
            url: "profile2.php",
            type: "POST",
            data: formData,
            dataType: "json",
            success: function (response) {
                if (response.success) {
                    $("#message").removeClass("d-none alert-danger").addClass("alert-success").html(response.message);
                    location.reload();
                } else {
                    $("#message").removeClass("d-none alert-success").addClass("alert-danger").html(response.message);
                }
            }
        });
    });
});
</script>

</body>
</html>

<?php include('footer.php'); ?>
