<?php
$zip = new ZipArchive;
$file = 'vendor.zip'; // Replace with your zip file name

if ($zip->open($file) === TRUE) {
    $zip->extractTo('.');
    $zip->close();
    echo 'Extraction successful!';
} else {
    echo 'Failed to extract the zip file.';
}
?>
