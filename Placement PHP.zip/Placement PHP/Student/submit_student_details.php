<?php
session_start();

include '../config/connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $control_id = mysqli_real_escape_string($conn, $_POST['control_id']);
    $dept_id = mysqli_real_escape_string($conn, $_POST['dept_id']);
    $year = mysqli_real_escape_string($conn, $_POST['year']); // Added Year field
    $cgpa = mysqli_real_escape_string($conn, $_POST['cgpa']);
    $no_of_atkt = mysqli_real_escape_string($conn, $_POST['noOfAtkt']);

    // Check if Control ID already exists
    $query = "SELECT control_id FROM students WHERE control_id = '$control_id'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        echo "<script>alert('Control ID already exists. You are already registered or Control ID is incorrect.'); window.history.back();</script>";
    } else {
        // Store data in session
        $_SESSION['control_id'] = $control_id;
        $_SESSION['dept_id'] = $dept_id;
        $_SESSION['year'] = $year; // Storing Year
        $_SESSION['cgpa'] = $cgpa;
        $_SESSION['no_of_atkt'] = $no_of_atkt;

        // Redirect to send OTP page
        header("Location: send-otp2.php");
        exit;
    }
}
?>

