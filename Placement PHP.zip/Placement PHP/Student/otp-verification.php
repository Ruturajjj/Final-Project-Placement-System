<?php
session_start();
include 'config/connect.php'; // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $enteredOtp = $_POST['otp'];

    // Check if the entered OTP matches the one stored in session
    if ($enteredOtp == $_SESSION['otp']) {
        // OTP is verified
        $_SESSION['otp_verified'] = true;

        // Insert data into the database
        $control_id = $_SESSION['control_id'];
        $dept_id = $_SESSION['dept_id'];
        $cgpa = $_SESSION['cgpa'];
        $no_atkt = $_SESSION['noOfAtkt'];
        $email = $_SESSION['email'];
        $password = $_SESSION['password'];
        $fullName = $_SESSION['fullName'];
        $year = $_SESSION['year'];

        // Insert query
        $sql = "INSERT INTO students (control_id, full_name, email, password, no_atkt, cgpa, year, dept_id)
                VALUES ('$control_id', '$fullName', '$email', '$password', '$no_atkt', '$cgpa', '$year', '$dept_id')";

        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Registration successful!'); window.location.href = 'success.html';</script>";
            session_destroy(); // Clear session after successful insertion
            header("Location: student_login3.php");
            exit;
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        $error = "Invalid OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid vh-100">
        <div class="row h-100">
            <div class="col-lg-6 col-md-6 d-none d-md-block bg-light text-center">
                <img src="https://via.placeholder.com/500x500" class="img-fluid h-100 w-100" alt="OTP Verification Image" style="object-fit: cover;">
            </div>
            <div class="col-lg-6 col-md-6 d-flex align-items-center justify-content-center bg-white">
                <div class="w-75">
                    <h2 class="text-center mb-4">OTP Verification</h2>
                    <?php if (isset($error)) { echo "<p class='text-danger'>$error</p>"; } ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="otp" class="form-label">Enter OTP</label>
                            <input type="text" class="form-control" id="otp" name="otp" placeholder="Enter the OTP sent to your email" required>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary w-100">Verify OTP</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
