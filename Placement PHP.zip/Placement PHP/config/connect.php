<?php
$host = 'localhost';
$username = 'root';//'placeme1_kelkar_placement';
$password =  '';    //'%y77xqC^toL#'
$dbname =   'placement';//'placeme1_placement';

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//echo " Connection Sucessful";

$sql = "CREATE TABLE IF NOT EXISTS department (
    dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(100) NOT NULL
)";

// Execute the query to create the table, without echoing success or failure messages
$conn->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS students (
    control_id INT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    no_atkt INT NOT NULL,
    cgpa DECIMAL(3,2) NOT NULL,
    year INT NOT NULL,
    dept_id INT NOT NULL,
    FOREIGN KEY (dept_id) REFERENCES department(dept_id)
)";

// Execute the query to create the table, without echoing success or failure messages
$conn->query($sql);

 $sql = "CREATE TABLE IF NOT EXISTS company (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
    
)";

$conn->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS job_internship (
    job_internship_id INT AUTO_INCREMENT PRIMARY KEY,
    job_title VARCHAR(255) NOT NULL,
    job_description TEXT NOT NULL,
    address VARCHAR(255) DEFAULT NULL,
    ctc_stipend VARCHAR(50) NOT NULL,
    type ENUM('job', 'internship') NOT NULL,
    no_kt_allowed INT NOT NULL,
    vacancies INT NOT NULL,
    duration VARCHAR(50) DEFAULT NULL,
    req_cgpa DECIMAL(3,2) NOT NULL
)";

$conn->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS offers (
    offer_id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    job_internship_id INT NOT NULL,
    FOREIGN KEY (company_id) REFERENCES company(id) ON DELETE CASCADE,
    FOREIGN KEY (job_internship_id) REFERENCES job_internship(job_internship_id) ON DELETE CASCADE
)";

$conn->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS job_for (
    job_for_id INT AUTO_INCREMENT PRIMARY KEY,
    job_internship_id INT NOT NULL,
    dept_id INT NOT NULL,
    FOREIGN KEY (job_internship_id) REFERENCES job_internship(job_internship_id) ON DELETE CASCADE,
    FOREIGN KEY (dept_id) REFERENCES department(dept_id) ON DELETE CASCADE
)";

$conn->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS apply (
    apply_id INT PRIMARY KEY AUTO_INCREMENT,
    job_internship_id INT NOT NULL,
    control_id INT NOT NULL,
    application_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Pending', 'Rejected', 'Selected') DEFAULT 'Pending',
    FOREIGN KEY (job_internship_id) REFERENCES job_internship(job_internship_id),
    FOREIGN KEY (control_id) REFERENCES students(control_id)
)";

$conn->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS admin (
admin_id INT PRIMARY KEY AUTO_INCREMENT,
email VARCHAR(100) NOT NULL,
password VARCHAR(20) NOT NULL
)";

$conn->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    announcement_text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

$conn->query($sql);

?>

