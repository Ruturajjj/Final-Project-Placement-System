<?php
session_start();
include('../config/connect.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_email'])) {
    header("Location: admin_login.php");
    exit;
}

// Check if student ID is provided
if (!isset($_GET['id'])) {
    header("Location: students.php");
    exit;
}

$control_id = $_GET['id'];

// Fetch student details
$query = "SELECT * FROM students WHERE control_id = '$control_id'";
$result = $conn->query($query);

if ($result->num_rows !== 1) {
    header("Location: students.php");
    exit;
}

$student = $result->fetch_assoc();

// Fetch all departments
$dept_query = "SELECT * FROM department";
$dept_result = $conn->query($dept_query);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $no_atkt = $_POST['no_atkt'];
    $cgpa = $_POST['cgpa'];
    $dept_id = $_POST['dept_id']; // Get selected department

    // Update student details
    $update_query = "UPDATE students SET email='$email', no_atkt='$no_atkt', cgpa='$cgpa', dept_id='$dept_id' WHERE control_id='$control_id'";
    
    if ($conn->query($update_query)) {
        header("Location: students.php");
        exit;
    } else {
        echo "<script>alert('Error updating student');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../images/college_logo.jpg">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Student</h2>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?= $student['email'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Department</label>
                <select name="dept_id" class="form-select" required>
                    <?php while ($dept = $dept_result->fetch_assoc()): ?>
                        <option value="<?= $dept['dept_id'] ?>" <?= ($dept['dept_id'] == $student['dept_id']) ? 'selected' : '' ?>>
                            <?= $dept['dept_name'] ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">No. of ATKTs</label>
                <input type="number" name="no_atkt" class="form-control" value="<?= $student['no_atkt'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">CGPA</label>
                <input type="text" name="cgpa" class="form-control" value="<?= $student['cgpa'] ?>" required>
            </div>
            <button type="submit" class="btn btn-success">Update Student</button>
            <a href="students.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>

<?php $conn->close(); ?>
