<?php
include('../config/connect.php');

if (!isset($_GET['company_id'])) {
    die("Invalid Request");
}

$company_id = $_GET['company_id'];

// Fetch jobs/internships for the selected company
$query = "SELECT ji.job_internship_id, ji.job_title, ji.type 
          FROM job_internship ji 
          JOIN offers o ON ji.job_internship_id = o.job_internship_id 
          WHERE o.company_id = $company_id";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jobs & Internships</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2 class="text-center mb-4">Jobs & Internships</h2>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Title</th>
                <th>Type</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td>
                        <a href="applied_students.php?job_id=<?php echo $row['job_internship_id']; ?>" class="btn btn-info w-100">
                            <?php echo $row['job_title']; ?>
                        </a>
                    </td>
                    <td><?php echo ucfirst($row['type']); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
