<?php
include "header.php";
session_start();
if (!isset($_SESSION['admin_email'])) {
    header("Location: login.php"); // Redirect if not logged in
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        .sidebar {
            height: 100vh;
            position: fixed;
            width: 250px;
            background: #343a40;
            padding-top: 20px;
        }
        .sidebar a {
            color: #fff;
            padding: 15px;
            display: block;
            text-decoration: none;
        }
        .sidebar a:hover {
            background: #495057;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h4 class="text-center text-light">Admin Panel</h4>
        <a href="students.php">📚 Students</a>
        <a href="companies.php">🏢 Companies</a>
        <a href="jobs.php">💼 Jobs</a>
        <a href="announcement.php">📢 Announcements</a>
        <a href="logout.php" class="text-danger">🚪 Logout</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h2>Welcome, Admin</h2>
        <p>Manage students, companies, and jobs from here.</p>
        
        <div class="row">
            <!-- Students Card -->
            <div class="col-md-3">
                <div class="card border-primary">
                    <div class="card-body text-center">
                        <h5 class="card-title">Students</h5>
                        <p class="card-text">Manage student records.</p>
                        <a href="students.php" class="btn btn-primary">View</a>
                    </div>
                </div>
            </div>

            <!-- Companies Card -->
            <div class="col-md-3">
                <div class="card border-success">
                    <div class="card-body text-center">
                        <h5 class="card-title">Companies</h5>
                        <p class="card-text">View and manage companies.</p>
                        <a href="companies.php" class="btn btn-success">View</a>
                    </div>
                </div>
            </div>

            <!-- Jobs Card -->
            <div class="col-md-3">
                <div class="card border-warning">
                    <div class="card-body text-center">
                        <h5 class="card-title">Jobs</h5>
                        <p class="card-text">Manage job listings.</p>
                        <a href="jobs.php" class="btn btn-warning">View</a>
                    </div>
                </div>
            </div>

            <!-- Announcements Card -->
            <div class="col-md-3">
                <div class="card border-danger">
                    <div class="card-body text-center">
                        <h5 class="card-title">Announcements</h5>
                        <p class="card-text">Post and manage announcements.</p>
                        <a href="announcement.php" class="btn btn-danger">Manage</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
