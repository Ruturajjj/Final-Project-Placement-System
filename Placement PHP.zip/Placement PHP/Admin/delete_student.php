<?php
session_start();
include('../config/connect.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_email'])) {
    header("Location: admin_login.php");
    exit;
}

// Check if student ID is provided
if (isset($_GET['id'])) {
    $control_id = intval($_GET['id']); // Sanitize ID to prevent SQL injection

    // Prepare and execute the DELETE query
    $stmt = $conn->prepare("DELETE FROM students WHERE control_id = ?");
    $stmt->bind_param("i", $control_id);

    if ($stmt->execute()) {
        // Redirect with success message
        $_SESSION['success_message'] = "Student with ID $control_id has been deleted successfully.";
    } else {
        // Redirect with error message
        $_SESSION['error_message'] = "Failed to delete student. Please try again.";
    }

    $stmt->close();
    $conn->close();

    // Redirect back to student management page
    header("Location: students.php");
    exit;
} else {
    // Redirect if ID is not set
    $_SESSION['error_message'] = "Invalid student ID.";
    header("Location: students.php");
    exit;
}
?>
