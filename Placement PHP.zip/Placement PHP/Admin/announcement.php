<?php
include "header.php";
session_start();
include('../config/connect.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_email'])) {
    header("Location: login.php");
    exit;
}

// Add Announcement
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_announcement'])) {
    $announcement = mysqli_real_escape_string($conn, $_POST['announcement']);
    $query = "INSERT INTO announcements (announcement_text, created_at) VALUES ('$announcement', NOW())";
    $conn->query($query);
    header("Location: announcement.php");
    exit;
}

// Delete Announcement
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    $query = "DELETE FROM announcements WHERE id = $id";
    $conn->query($query);
    header("Location: announcement.php");
    exit;
}

// Fetch Announcements
$announcementQuery = "SELECT * FROM announcements ORDER BY created_at DESC";
$announcements = $conn->query($announcementQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../images/college_logo.jpg">
    <title>Manage Announcements</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card-header {
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4">📢 Announcement Management</h2>

    <!-- Add Announcement Section -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">📝 Add Announcement</div>
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <textarea name="announcement" class="form-control" rows="3" required placeholder="Write an announcement..."></textarea>
                </div>
                <button type="submit" name="add_announcement" class="btn btn-primary">Announce</button>
            </form>
        </div>
    </div>

    <!-- Manage Announcements Table -->
    <div class="card">
        <div class="card-header bg-dark text-white">📜 All Announcements</div>
        <div class="card-body">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Announcement</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $announcements->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id']) ?></td>
                        <td><?= htmlspecialchars($row['announcement_text']) ?></td>
                        <td><?= $row['created_at'] ?></td>
                        <td>
                            <a href="?delete_id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this announcement?');">🗑 Delete</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
