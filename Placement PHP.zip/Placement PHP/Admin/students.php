<?php
include "header.php";
session_start();
include('../config/connect.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_email'])) {
    header("Location: admin_login.php");
    exit;
}

// Handle student deletion
if (isset($_GET['delete_id'])) {
    $control_id = intval($_GET['delete_id']);
    $deleteQuery = "DELETE FROM students WHERE control_id = $control_id";

    if ($conn->query($deleteQuery)) {
        $deleteMessage = "Student with ID $control_id has been deleted successfully.";
    } else {
        $deleteError = "Failed to delete student. Please try again.";
    }
}

// Fetch students data
$query = "SELECT s.control_id, s.full_name, s.year, s.email, d.dept_name, s.no_atkt, s.cgpa 
          FROM students s
          JOIN department d ON s.dept_id = d.dept_id
          ORDER BY s.control_id";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../images/college_logo.jpg">
    <style>
        .table-container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            text-align: center;
            vertical-align: middle !important;
            white-space: nowrap;
        }
        .btn {
            padding: 5px 10px;
            font-size: 14px;
        }
    </style>
    <script>
        function searchStudents() {
            let input = document.getElementById("search").value.toLowerCase();
            let table = document.getElementById("studentTable");
            let rows = table.getElementsByTagName("tr");

            for (let i = 1; i < rows.length; i++) {
                let controlID = rows[i].getElementsByTagName("td")[0]?.innerText.toLowerCase() || "";
                let fullName = rows[i].getElementsByTagName("td")[1]?.innerText.toLowerCase() || "";

                if (controlID.includes(input) || fullName.includes(input)) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        }

        function confirmDelete(controlId) {
            if (confirm("Are you sure you want to delete this student?")) {
                window.location.href = "?delete_id=" + controlId;
            }
        }
    </script>
</head>
<body style="background-color: #f8f9fa;">

<div class="container mt-5">
    <div class="table-container">
        <h2 class="mb-4 text-center text-primary">Student Management</h2>

        <!-- Success/Error Messages -->
        <?php if (isset($deleteMessage)): ?>
            <div class="alert alert-success"><?= $deleteMessage ?></div>
        <?php endif; ?>
        <?php if (isset($deleteError)): ?>
            <div class="alert alert-danger"><?= $deleteError ?></div>
        <?php endif; ?>

        <!-- Search Bar -->
        <div class="card mb-3">
            <div class="card-body">
                <input type="text" id="search" class="form-control" placeholder="Search by Control ID or Name" onkeyup="searchStudents()">
            </div>
        </div>

        <!-- Student Table -->
        <div class="table-responsive">
            <table id="studentTable" class="table table-hover table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th style="width: 10%;">Control ID</th>
                        <th style="width: 15%;">Full Name</th>
                        <th style="width: 20%;">Email</th>
                        <th style="width: 15%;">Department</th>
                        <th style="width: 10%;">Year</th>
                        <th style="width: 10%;">No. of ATKTs</th>
                        <th style="width: 10%;">CGPA</th>
                        <th style="width: 15%;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['control_id']) ?></td>
                            <td><?= htmlspecialchars($row['full_name']) ?></td>
                            <td><?= htmlspecialchars($row['email']) ?></td>
                            <td><?= htmlspecialchars($row['dept_name']) ?></td>
                            <td><?= htmlspecialchars($row['year']) ?></td>
                            <td><?= htmlspecialchars($row['no_atkt']) ?></td>
                            <td><?= htmlspecialchars($row['cgpa']) ?></td>
                            <td>
                                <a href="edit_student.php?id=<?= $row['control_id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                <button class="btn btn-danger btn-sm" onclick="confirmDelete(<?= $row['control_id'] ?>)">Delete</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>
