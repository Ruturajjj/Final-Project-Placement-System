<?php

include "header.php";
session_start();
include('../config/connect.php');

// Check if admin is logged in
if (!isset($_SESSION['admin_email'])) {
    header("Location: admin_login.php");
    exit;
}

// Fetch companies along with job/internship count
$query = "
    SELECT c.id AS company_id, c.company_name, c.email, COUNT(o.offer_id) AS job_count 
    FROM company c 
    LEFT JOIN offers o ON c.id = o.company_id 
    GROUP BY c.id
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Companies</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="../images/college_logo.jpg">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Companies</h2>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Company Name</th>
                    <th>Email</th>
                    <th>No. of Jobs/Internships</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php $count = 1; ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $count++ ?></td>
                            <td><?= htmlspecialchars($row['company_name']) ?></td>
                            <td><?= htmlspecialchars($row['email']) ?></td>
                            <td><?= $row['job_count'] ?></td>
                            <td>
                                <a href="edit_company.php?id=<?= $row['company_id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="delete_company.php?id=<?= $row['company_id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this company?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">No companies found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php $conn->close(); ?>
