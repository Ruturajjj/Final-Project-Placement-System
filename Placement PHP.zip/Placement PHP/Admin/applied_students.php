<?php
include "header.php";
include('../config/connect.php');

if (!isset($_GET['job_id'])) {
    die("Invalid Request");
}

$job_id = $_GET['job_id'];

// Handle status update
if (isset($_POST['update_status'])) {
    $control_id = $_POST['control_id'];
    $status = $_POST['status'];

    $update_query = "UPDATE apply SET status = '$status' 
                     WHERE job_internship_id = $job_id AND control_id = '$control_id'";
    
    if (mysqli_query($conn, $update_query)) {
        // Reload the page after updating status
        header("Location: applied_students.php?job_id=$job_id");
        exit();
    } else {
        echo "<div class='alert alert-danger'>Error updating status: " . mysqli_error($conn) . "</div>";
    }
}

// Fetch students who applied for the job/internship with department info
$query = "SELECT s.control_id, s.full_name, s.email, s.cgpa, s.year, s.no_atkt, a.status, d.dept_name 
          FROM apply a 
          JOIN students s ON a.control_id = s.control_id 
          JOIN department d ON s.dept_id = d.dept_id
          WHERE a.job_internship_id = $job_id";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applicants</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2 class="text-center mb-4">Applicants</h2>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Student Name</th>
                <th>Control ID</th>
                <th>Email</th>
                <th>CGPA</th>
                <th>Year</th>
                <th>No of KTs</th>
                <th>Department</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $row['full_name']; ?></td>
                    <td><?php echo $row['control_id']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['cgpa']; ?></td>
                    <td><?php echo $row['year']; ?></td>
                    <td><?php echo $row['no_atkt']; ?></td>
                    <td><?php echo $row['dept_name']; ?></td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="control_id" value="<?php echo $row['control_id']; ?>">
                            <select name="status" class="form-select" onchange="this.form.submit()">
                                <option value="Pending" <?php if ($row['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                                <option value="Selected" <?php if ($row['status'] == 'Selected') echo 'selected'; ?>>Selected</option>
                                <option value="Rejected" <?php if ($row['status'] == 'Rejected') echo 'selected'; ?>>Rejected</option>
                            </select>
                            <input type="hidden" name="update_status" value="1">
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


